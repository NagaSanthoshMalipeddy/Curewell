export class Specialization {
    specializationCode:string;
    specializationName:string;
}
