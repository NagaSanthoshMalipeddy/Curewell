export class Surgery {
    surgeryId:number;
    doctorId?:number;
    surgeryDate:Date;
    startTime:number;
    surgeryCategory?:string;
    endTime:number;
}
