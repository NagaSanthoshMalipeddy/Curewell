export class DoctorSpecialization {
    DoctorId:number;
    SpecializationCode:string;
    SpecializationDate:Date;
}
