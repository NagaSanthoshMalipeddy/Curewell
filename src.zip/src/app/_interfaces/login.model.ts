export interface LoginModel {
  username: string;
  password: string;
}